![Banner Calculator Dialog](img/banner.png)
